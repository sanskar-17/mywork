//wap to find the sum of all the elements of an array using pointers
#include<stdio.h>
main()
{
	int i,n,s=0;
	printf("enter the no.of elements in the array\n");
	n=scanf("%d",&n);
	int a[n];
	int *p=a;
	printf("enter the elements of the array\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	// finding sum
	for(i=0;i<n;i++)
	{
		s+=*(a+i);
	}
	printf("sum =%d",s);
}
