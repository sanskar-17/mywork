#include<stdio.h>
main()
{
	int a=6,b=5,c=10,d,e,f;
	d=(a==b)&&(c>b);
	printf("the (a==b) && (c>b)=%d\n",d );
	e=(a==b)||(c>b);
	printf("the (a==b) && (c>b)=%d\n",e );
	f=!(a==b);
	printf("the ! of(a==b)=%d\n",f );	
}
