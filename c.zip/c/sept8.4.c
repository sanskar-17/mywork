#include<stdio.h>
void print1();
main()
{
	print();
}
void print()
{
	printf("gand marao");
		
}
