#include<stdio.h>
void ref1(int a );
main()
{
	int arr[5]={1,2,3,4,5};
	ref1(arr[3]);
}
void ref1(int a )
{
	printf("%d\n",a);
	
}
