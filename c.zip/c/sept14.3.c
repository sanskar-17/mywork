#include<stdio.h>
extern int a=10;
main()
{
	printf("value of global a inside main is %d",a);
	{
		int a=90;	 
	 	printf("\nvalue of a inside the nested block is %d",a);
	}
}
