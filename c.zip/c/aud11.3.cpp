#include<stdio.h>
main()
{
	char a='a',b='b';
	int addn;
	addn='A'+1;
	printf("%d",addn);
	printf("\n%c",addn);

}
