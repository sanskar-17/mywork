//type define function
#include<stdio.h>
main()
{
	typedef int I;
	typedef char C;
	I x=5;
	printf("%d",x);
	C a='A';
	printf("\n%c",a);
	
}
