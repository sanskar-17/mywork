#include<stdio.h>
main()
{
	int i,n,j,t;
	printf("enter the no. of elements\n");
	scanf("%d",&n);
	int a[n];
	printf("enter the elements in array\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	//sorting
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(a[j]>a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
	printf("the sorted array is\n");
	for(i=0;i<n;i++)
	{
		printf("%d\n",a[i]);
	}
}
