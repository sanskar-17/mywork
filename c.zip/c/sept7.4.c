#include<stdio.h>
main()
{
/*	printf("%04d\n",123);
	printf("%04d\n",1235);
	printf("%04d\n",1234);
	printf("%-4d\n",1234);*/
	int i=897;
	float f=123.67812;
	char c[]="HAPPY JANAMASHTMI";
	printf("%.5d",i);
	printf("\n%.1f",f);
	printf("\n%.8s",c);

	
}
