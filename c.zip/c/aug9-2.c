#include<stdio.h>
main()
{
	int c=57;
	char chr;
	chr=c;
	printf("%c",chr);
	
}
