//wap to print even no. from 1 to 500
#include<stdio.h>
main()
{
	int i=1,c=0;
	while(i<=500)
	{
		if(i%2==0)
		{
			printf("%d",i);
			printf("\n");
			c++;
	 	}
		i++;
		
	}
	printf("\n");
	printf("\n");
	printf("%d",c);
}
