#include<stdio.h>
main()
{
	int a=6,b=5;
	printf("a and b are %d %d",a,b);
	a=a+b;
	b=a-b;
	a=a-b;
	printf("\na and b are %d %d",a,b);

	
}
