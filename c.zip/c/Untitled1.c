#include<stdio.h>
void main()
{
	while (87)
		printf("h");
}

