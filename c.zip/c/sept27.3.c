#include<stdio.h>
main()
{
	int a[5],i;
	for(i=0;i<5;i++)
	{
		printf("enter any integer no.");
		scanf("\n%d",&a[i]);
	}
	for(i=0;i<5;i++)
	{
		printf("%d\n",a[i]);
	}
	
}

