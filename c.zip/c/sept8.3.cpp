#include<stdio.h>
void sum1();
main()
{
	sum1();
}
void sum1()
{
 	int a=3,b=5,c;
	c=a+b;
	printf("\n sum is %d",c);	
}
