#include<stdio.h>
#include "one.c"
main()
{
	print1();
}
