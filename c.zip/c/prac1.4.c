#include<stdio.h>
main()
{
	int a=125,b=12345;
	long ax=1234567890;
	short s=4043;
	float x=2.13459;
	double dx= 1.1415927;
	char c='W';
	unsigned long ux=2541567890;
	printf("%d",(a+c));
 	printf("\n%f",(x+c));
 	printf("\n%lf",(dx+x));
 	printf("%ld",((int)dx)+ax);
 	printf("\n%f",(a+x));
 	printf("\n%d",(s+b));
 	printf("\n%ld",(ax+b));
 	printf("\n%hu",(s+c));
 	printf("\n%ld",(ax+c));
 	printf("\n%u",(ax+ux));
 	
	
}
