#include<stdio.h>
main()
{
	int a,b;
	printf("enter the value of a & b \n");
	scanf("%d %d",&a,&b);
	
	if (a>b)
	{
		printf("a = %d is greater than b = %d",a,b);
	}
	if (b>a)
	{
		printf("b = %d is greater than a = %d",b,a);
	}
}

