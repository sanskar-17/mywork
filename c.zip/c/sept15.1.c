#include<stdio.h>
extern int a=20;
int y=8;
void mystatic()
{
	static int j=5;
	printf("the value of static variable  j in  function is %d\n",j);
	j++;
	printf("the value of a isn the function is %d\n",a++);
}
main()
{
	int w;
	static int d;
	register int x=7,m;
	auto int k;
	k=y*y;
	printf("the value of k is %d\n",k);
	m= x*x;
	printf("the value of m is %d\n",m);
	mystatic();
	mystatic();
	mystatic();
	mystatic();
}


