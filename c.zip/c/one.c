#include<stdio.h>
extern int a=9;
void print1()
{
//	extern int a=9;
	printf("the value is %d",a);
	a+=10;
}
