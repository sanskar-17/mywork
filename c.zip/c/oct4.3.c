//linear searching
#include<stdio.h>
main()
{
	int arr[50];
	int i,l=-1,key,n=5;//n is the no. of elements
	printf("enter the size ");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter the element in array\n");
		scanf("%d",&arr[i]);
	}
	key=45;//the no. that we want to search
	for(i=0;i<n;i++)
	{
		if(arr[i]==key)
		{
		l=0;
		break;
		}
	}
	if(l==0)
	printf("element %d found at %d position",key,(i+1));
	else
	printf("element not found");	
}
