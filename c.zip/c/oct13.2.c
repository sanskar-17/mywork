#include<stdio.h>
main()
{
	int *nptr;
	char *cptr;
	float *fptr;
	printf("size of int pointer is%d\n",sizeof(nptr));
	printf("size of char pointer is%d\n",sizeof(cptr));
	printf("size of float pointer is%d\n",sizeof(fptr));
}
