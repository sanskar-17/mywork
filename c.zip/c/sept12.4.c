//with parameter and return
#include<stdio.h>
int sum1(int a,int b)
{
	int c=a+b;
//	printf("output inside the function = %d ",c);
	return c;
}
main()
{
	int a=10,b=20,c;
	c=sum1(a,b);
	printf("sum = %d",c);
}

