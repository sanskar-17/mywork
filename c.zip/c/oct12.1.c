#include<stdio.h>
main()
{
	int a[3][3],b[3][3],c[3][3],d[3][3],i,j,k;
	printf("enter the elements in the dda a\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	printf("enter the elements in the dda b\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf("%d",&b[i][j]);
		}
	}
	//displaying the matrix
	printf("the elements of array a are\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	}
	printf("the elements of array b are\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d\t",b[i][j]);
		}
		printf("\n");
	}
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			c[i][j]=a[i][j]+b[i][j];
		}
	}
	printf("the sum of arrays a and b in array c is \n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d\t",c[i][j]);
		}
	printf("\n");
	}
	for(i=0;i<3;i++)
	{
		d[i][j]=0;
		for(j=0;j<3;j++)
		{
			for(k=0;k<3;k++)
			{
				d[i][j]+=a[i][k]*b[j][k];	
			}
		}
	}	
	printf("the product of arrays a and b in array d is \n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d\t",d[i][j]);
		}
	printf("\n");
	}	
}
