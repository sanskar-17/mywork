#include<stdio.h>
main()
{
	int a ;
	a=~0+1;
	printf("%d",a);
	
}

