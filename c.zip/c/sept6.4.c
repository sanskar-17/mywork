#include<stdio.h>
main()
{
	int a=10,b=5,c,ch;
	printf("enter your choice  ");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
			printf("your choice is addition\n");
			c=a+b;
			printf("output=%d",c);
			break;
		case 2:
			printf("your choice is subtraction\n");
			c=a-b;
			printf("output=%d",c);
			break;
		default	:
			printf("there is no such option");
			
	}
}
