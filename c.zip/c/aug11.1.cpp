#include<stdio.h>
main()
{
	int a=12.5,b=3;
	int addn,subtn,multn,divdn,modulus;
	addn=a+b;
	subtn=a-b;
//	multn=a*b;
//	divdn=a/b;
//	modulus=a%b;
	printf(" sum= %f",addn);
	printf("\n subtraction= %f",subtn);
//	printf("\n product= %d",multn);
//	printf("\n quotient= %d",divdn);
//	printf("\n remainder= %d",modulus);
	
}
