#include<stdio.h>
main()
{
	int day=17,mon=07,year=2003;
	char a[7]="SANSKAR";
	char mob[10]="7906057662";
	printf("%s",a);
	printf("\n%d/%d/%d",day,mon,year);
	printf("\n%s",mob);
	
	
	
	
}
