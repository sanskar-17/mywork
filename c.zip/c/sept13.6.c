#include<stdio.h>
#include<math.h>
main()
{
	double x=9.4,y=8.0,z=7.0;
	printf("\n value =%lf",ceil(x));
	printf("\n value =%lf",floor(x));
	printf("\n value =%lf",pow(9,3));

}
