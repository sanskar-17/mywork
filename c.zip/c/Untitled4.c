#include<stdio.h>
int main()
{
	printf("today is tuesday");
	return 0;
}
