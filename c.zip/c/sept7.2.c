#include<stdio.h>
main()
{
	int x,y,z;
	printf("enter the values of x,y and z\n");
	scanf("\n%d %d %d",&x,&y,&z);
	if (x>y && x>z)
	goto label1;
	else if (y>x && y>z)
	goto label2;
	else
	goto label3;
	label1: printf("x is largest");
	label2: printf("y is largest ");
	label3: printf("z is largest");
		
}
