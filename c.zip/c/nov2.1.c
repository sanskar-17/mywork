//inbuilt functions in string library
#include<stdio.h>
#include<string.h>
main()
{
	float x1,x2;
	char s1[50]="Hello ";
	char s2[20]="Helao";
//	strcat(s1,s2);printf("%s",s1);
//	strncat(s1,s2,4);
//	x=strncmp(s1,s2,4);
//	x1=strlen(s1);
//	printf("%d",x1);
//	x2=strlen(s2);
//	printf("%s",strrev(s1));
//	printf("%s",strlwr(s1));
//	printf("\n%s",strupr(s1));
    char sn[20]="12345.987";
    x1=atof(sn);
    printf("%.2f",x1);
}
