//embedded structures
#include<stdio.h>
struct student
{
	int regno;
	struct result
	{		
		int marks;
	}r1;
}s1;
main()
{
	s1.regno=1;
	s1.r1.marks=98;
	printf("registration no.=%d\n",s1.regno);
	printf("marks =%d\n",s1.r1.marks);	
}
