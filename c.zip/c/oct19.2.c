#include<stdio.h>
main()
{
/*   WILD POINTER
	int *ptr;
	printf("value of ptr is %d",*ptr);*/
/* NULL POINTER
	int *ptr=NULL;
	printf("value of ptr is %d",ptr);*/
//GENERIC POINTER
	int x=10,b=9;
	char c='A';
	void *ptr;
	ptr=&x;
	printf("value of ptr is %d ",*(int*)ptr);
	ptr=&c;
	printf("value of ptr is %c ",*(char*)ptr);
			
}
