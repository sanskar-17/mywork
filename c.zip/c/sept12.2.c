//no parmeter but return
#include<stdio.h>
int sum1()
{
	int x=10,y=20,w;
	w=x+y;
	return w;	
}
main()
{
	int a,b;
	a=sum1();
	printf("%d",a);
}
