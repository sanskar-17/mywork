#include<stdio.h>
main()
{
	int *ptr1,**ptr2,***ptr3,i;
	i=5;
	ptr1=&i;
	ptr2=&ptr1;
	ptr3=&ptr2;
	printf("%d\n",i);
	printf("%d\n",ptr1);
	printf("%d\n",ptr2);
	printf("%d\n",ptr3);
	printf("\n");
	printf("%d\n",*ptr1);
	printf("%d\n",*ptr2);
	printf("%d\n",*ptr3);	
}
