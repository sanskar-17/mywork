#include<stdio.h>
main()
{
	int a=12,b=47,c=83;
	if (a>b && a>c)
	{
		printf("a is largest");
	}
	else if (b>a && b>c)
	{
		printf("b is largest ");
	}
	else 
	{
		printf("c is largest");
	}		
}

