#include<stdio.h>
main()
{
	int p=2;
	float a=3.0123418;
	char c='Sanskar m';
	double dd=5.78247;
	printf("int value is= %d \n float value is= %f \n char value is=%c \n double value is =%lf",p,a,c,dd);
	char chr[]={'s','h','i','v','a'};
	printf("\n%s",chr)	;
}
