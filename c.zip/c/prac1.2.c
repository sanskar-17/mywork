#include<stdio.h>
main()
{
	char a='X',b='M',c='L';
	printf("%c %c %c",a,b,c);
	printf("\n reverse order is %c %c %c ",c,b,a);
	
	
}
