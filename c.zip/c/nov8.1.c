#include<stdio.h>
#include<string.h>
struct emp
{
	char name[20];
	int age;
	int salary;
};
main()
{
	int i;
	struct emp e1[100];
	for(i=0;i<2;i++)
	{
		printf("Enter the name, age , and salary\n");
		gets(e1[i].name);
		fflush(stdin);
		scanf("%d",&e1[i].age);
		fflush(stdin);
		scanf("%d",&e1[i].salary);
		fflush(stdin);
	}
		for(i=0;i<2;i++)
	{
//		printf("Enter the name, age , and salary\n");
		printf("%s\n",e1[i].name);
		printf("%d\n",e1[i].age);
		printf("%d\n",e1[i].salary);
	}
}
