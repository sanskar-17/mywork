#include<stdio.h>
#include<string.h>
struct student 
{
	int rollno ;
	int marks[3];
};
main()
{
	int i ;
	struct student s1;
	s1.rollno=1;
	printf("enter the marks\n");
	for(i=0;i<3;i++)
	{
		scanf("%d",&s1.marks[i]);
	}
	printf("%d\n",s1.rollno);
	for(i=0;i<3;i++)
	printf("%d\n",s1.marks[i]);
}
