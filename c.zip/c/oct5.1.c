#include<stdio.h>
main()
{
	int l,i,m,u,n,key,flag=0;
	printf("enter the size of the array\n");
	scanf("%d",&n);
	int a[n];
	l=0;
	u=n-1;
	printf("enter the elements in array\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("enter the no. to be searched\n");
	scanf("%d",&key);
	while(l<=u)
	{
		m=(l+u)/2;
		if(key==a[m])
		{
			flag=1;
			break;
		}
		else if (key>a[m])
		l=m+1;
		else
		u=m-1;		
	}
	if(flag==1)
	printf("%d found at %d",key,m+1);
	else
	printf("%d not found ",key);
}
