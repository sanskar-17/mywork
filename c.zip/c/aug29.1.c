#include<stdio.h>
main()
{
	int i=1;
	while(i<=10)
	{
		printf("%d",i);
		printf("\n");
		i++;
	}
}
