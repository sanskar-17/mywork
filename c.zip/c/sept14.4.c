#include<stdio.h>;
extern a=10;
fun1()
{
	printf("\nvalue pf global a inside fun1 is %d",a);
	a++;
}
fun2()
{
	int a=9;
	printf("\n value of a in fun2 is %d",a);
	a++;
}
main()
{
	fun1();
	fun1();
	fun1();
	fun2();
	fun2();
	fun2();
	
}
