#include<stdio.h>
main()
{
	int a;
	float h;
	char c[21];
	printf("enter the age and height\n");
	scanf("%d %f",&a,&h);
	printf("enter the string\n");
	scanf("%s",c);
	printf(" \nthe values of age and height are ");
	printf("%d %f",a,h);
	printf("\nthe string is \n");
	printf("%s",c);
}
