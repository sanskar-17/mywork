#include<string.h>
#include<stdio.h>
#include<stdlib.h>
main()
{
//	int a=23;
	char x='a'+'c';
	//char str[100];
	//itoa(a,str,8);
	printf("%c",x);
}
