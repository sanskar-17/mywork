#include<stdio.h>
main()
{
	int a=10,b=0,c=2,d;
	d=a&&b||c-2;
	printf("%d",d);
}
