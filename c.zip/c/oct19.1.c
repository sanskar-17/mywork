#include<stdio.h>
/*void swap1(int x, int y)
{
	int t;
	t=x;
	x=y;
	y=t;
	printf("values of a and b = %d , %d",x,y);
}*/
void swap1(int *x, int *y)
{
	int t;
	int *ptemp=&t;
	*ptemp=*x;
	*x=*y;
	*y=*ptemp;
	printf("values of a and b = %d,%d\n",*x,*y);
}
main()
{
	int a=7,b=9;
	printf("values of a and b before swapping = %d , %d \n",a,b);
	swap1(&a,&b);
	printf("values of a and b after swapping = %d , %d\n ",a,b);
}

