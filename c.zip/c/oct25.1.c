//pointer to an array
#include<stdio.h>
main()
{
	int a[5];
	int *ptr=a,i;
	printf("Enter the elements in the array\n");
	for(i=0;i<5;i++)
	{
		scanf("%d",ptr+i);
	}
	printf("The array elements are:\n");
	for(i=0;i<5;i++)
	printf("%d ",*(ptr+i));
	
}
