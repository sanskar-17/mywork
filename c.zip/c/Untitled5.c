#include<stdio.h>
main()
{
	int x,y,z;
	x=9;
	y=0;
	z=90;
	char c='a';
	float f=8.9;
	printf("%d %d %d %f %c",x,y,z,f,c);
}
