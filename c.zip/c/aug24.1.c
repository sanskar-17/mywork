#include<stdio.h>
main()
{
	int a=6,b=4;
	if (a>b)
	{
		printf("a = %d is greater than b = %d",a,b);
	}
/*	else
	{
		printf("b = %d is greater than a = %d",b,a);
	}*/
}
