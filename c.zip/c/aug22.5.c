//escape sequences

#include<stdio.h>
main()
{
	// \b backspace
	printf("hello \b\b\b hi friends");
	printf("\nhi \vi\vam\vsee\vstudent\a");
	printf("\n hello friends\rend");
	printf("\nhello  \" friends");
}
