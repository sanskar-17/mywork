#include<stdio.h>
#include<conio.h>
main()
{
	char c;
	printf("enter a character\n");
	c=getchar();
	putchar(c);
	printf("\n");
	char ch=getch();//we can use getche() also but that will display the input also that we give which will not be the case with getch()
	putch(ch);		
}

