#include<stdio.h>
main()
{
	int a=5,b,c;
	printf("the value of a before unary operator is %d",a);
//	b=++a;
	b=--a;
	printf("\nthe value of a after unary operator is %d",a);
	printf("\nthe value of b after unary operator is %d",b);
	b=--a;
	printf("\nthe value of a after unary operator is %d",a);
	printf("\nthe value of b after unary operator is %d",b);
	c=a+++b;
	printf("\nvalue of c is %d",c);
	
}

