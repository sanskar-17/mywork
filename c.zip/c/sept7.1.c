#include<stdio.h>
main()
{
	int i;
	for(i=2;i<10;i++)
	{
		if(i%2==1)
		continue;
		printf("\n%d",i);
		
	}
	printf("\n");	
		for(i=2;i<10;i++)
	{
		if(i%2==1)
		break;
		printf("\n%d",i);
		
	}
		printf("\n");	

		for(i=2;i<10;i++)
	{
		if(i%2==1)
		goto abc;
	}	
	abc: printf("get lost");	
}

