#include<stdio.h>
main()
{
	int arr[5]={3,5,9,4,7},i;
	for(i=0;i<5;i++)
	{
	printf("the addresses are %u \n",&arr[i]);
	}
}
