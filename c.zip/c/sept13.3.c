#include<stdio.h>
fun()
{
	printf("hi");
	fun();
}
main()
{
	fun();
	
	
}
