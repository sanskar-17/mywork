//use of const to render any variable as constant
#include<stdio.h>
main()
{
	int age =21;
	const float f=4.67;
	const char c='a';
	printf("%d",age);
	c='b';
	printf("\n%d",age);
}
