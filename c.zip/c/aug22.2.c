#include<stdio.h>
main()
{
	int age;
	printf("enter the age\n");
	scanf("%d",&age);
	(age>=18)?(printf("eligible to vote")):(printf("not eligible to vote"));
	
}
