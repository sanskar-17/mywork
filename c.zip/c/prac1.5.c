#include<stdio.h>
main()
{
	int days,years,weeks;
	days=1329;
	years=days/365;
    days=days%365;
	weeks=days/7;
	days=days%7;
	printf("years = %d ",years);
	printf("weeks = %d ",weeks);
	printf("days = %d ",days);


	
}
