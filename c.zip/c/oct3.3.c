#include<stdio.h>
void ref1(int x[],int size)
{
	int i,lar=x[0],sml=x[0];
	for(i=0;i<5;i++)
	{
		if(x[i]>lar)
		lar=x[i];
		if(x[i]<sml)
		sml=x[i];
	}
	printf("largest is %d\n",lar);
	printf("smallest is %d\n",sml);
	
}
main()
{
	int arr[5]={1,2,3,4,5};
	ref1(arr,5);
}

