#include<stdio.h>
main()
{
	int i,a[]={10,2,3,4,5};
	int *p=a;//this works same as *p=&a[] as name of the array is pointer itself therfore we do not need to use a pointer with array
	printf("%d\n",*p);
	printf("%d\n",*(p+1));
	printf("\n\n");
	for(i=0;i<5;i++)
		printf("%d\t",*(p+i));
	
}
