//calloc
#include<stdio.h>
#include<stdlib.h>
main()
{
	int *p,n,i;
	printf("enter the no. of integers to be used\n");
	scanf("%d",&n);
	p=(int*)calloc(n,(sizeof(int)));
	if(p==NULL)
	{
		printf("no memory available\n");
		exit(1);
	}
	else
	{
		printf("memory allocation successfull\n");
		printf("print values here\n");
		for(i=0;i<n;i++)
		scanf("%d",p+i);
		printf("\n \n");
		for(i=0;i<n;i++)
		printf("%d\n",*(p+i));
	}
}
