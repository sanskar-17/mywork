//register 
#include<stdio.h>
#include<math.h>
main()
{
	register int a=19;
	printf("a=%d",a)	;
}
