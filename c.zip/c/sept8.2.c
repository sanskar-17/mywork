#include<stdio.h>
main()
{
	char str[30];
	gets(str);
	puts(str);
	printf("%s",str);
}
