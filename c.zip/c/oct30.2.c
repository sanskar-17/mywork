#include<stdio.h>
#include<string.h>
main()
{
	char name[20];
	scanf("%s",name);
	printf("entered name is %s",name);
}
