#include<stdio.h>
int sum1(int n)
{
	if (n==0)
	return 0;
//	else if (n==1)
//	return 1;
	else
	return n+sum1(n-1);
}
main()
{
	
	printf("%d",sum1(5));	
	
}

