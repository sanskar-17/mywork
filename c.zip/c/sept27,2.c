#include<stdio.h>
main()
{
	int a[5]={1,2,3,4,5};
	printf("%d",a[1]);
	printf("\nthe size of thr array is %d",sizeof(a));	
}
