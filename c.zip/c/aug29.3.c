//to find no. of digits in a sequence
#include<stdio.h>
main()
{
	int n,x,c=0;
	printf("Enter any no.");
	scanf("%d",&n);
	while(n>0)
	{
		x=n/10;
		n/=10;
		c++;
	}
	printf("the no. of digits is %d",c);
}
