#include<stdio.h>
main()
{
	int i,n;
	printf("enter the size of the array\n");
	scanf("%d",&n);
	int arr[n];
	for(i=0;i<n;i++)
	{
		printf("enter the element into array\n");
		scanf("%d",&arr[i]);
	}
		for(i=0;i<n;i++)
		printf("%d\n",arr[i]);	
}
