#include<stdio.h>
main()
{
	printf("enter the size of the array");
	int n;
	scanf("%d",&n);
	int a[n],i;
	for(i=0;i<n;i++)
	{
		printf("enter any integer no.");
		scanf("\n%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		printf("%d\n",a[i]);
	}
	
}

