#include<stdio.h>
#include<string.h>
struct emp
{
	char name[20];
	int age;
	int salary;
}
main()
{
	struct emp e1={"saksham",19,1234567	};
	struct emp *ptr;
	ptr =&e1;
	printf("name is %s, age is %d,salary is %d\n",e1.name,e1.age,e1.salary);
	
	printf("name is %s, age is %d,salary is %d\n",ptr->name,ptr->age,ptr->salary);
	
	printf("name is %s, age is %d, salary is %d\n",(*ptr).name,(*ptr).age,(*ptr).salary);
}
