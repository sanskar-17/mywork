#include<stdio.h>
main()
{
	int a=6,b=4;
	(a>b)?(printf("a is greater = %d",a)):(printf("b is greater = %d",b));
	
}
