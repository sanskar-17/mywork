#include<stdio.h>
main()
{
	int a=6,b=5,c=10;
	printf("%d==%d is %d",a,b,a==b);
	printf("\n%d>=%d is %d",a,b,a>=b);
	printf("\n%d<=%d is %d",a,b,a<=b);
	printf("\n%d!=%d is %d",a,b,a!=b);
	printf("\n%d>%d is %d ",a,b,a>b);
	printf("\n%d<%d is %d",a,b,a<b);
	

	
}
