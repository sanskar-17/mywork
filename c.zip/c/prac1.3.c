#include<stdio.h>
main()
{
	float h=5.0,b=4.0,a,p;
	p=2*(h+b);
	a=h*b;
	printf("length=%f",h);
	printf("\nbreadth=%f",b);
	printf("\narea=%f",a);
	printf("\nperimeter=%f",p);
	
}
