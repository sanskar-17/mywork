#include<stdio.h>
main()
{
	int id,hours,sph=15000;
	float salary;
	printf(" input the employee id and his working hours\n");
	scanf("\n%d %d",&id,&hours);
	salary=hours*sph;
	printf("Employee id is %d",id);
	printf("\nSalary recived is %f",salary);
	
}
