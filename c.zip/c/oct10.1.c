#include<stdio.h>
main()
{
	int i;
	int a[6]={3,4,1,7,8,9};
	for(i=0;i<6;i++)
	printf("%d\n",a[i]);
	//insertion
	for(i=6;i>2;i--)
	a[i]=a[i-1];
	a[2]=10;
	printf("The new array is\n");
	for(i=0;i<7;i++)
	printf("%d\n",a[i]);
}
