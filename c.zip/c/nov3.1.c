#include<stdio.h>
#include<string.h>
#include<stdlib.h>
main()
{
	char str[200];
	int i,l=0;
	printf("enter the string\n");
	gets(str);
	for(i=0;;i++)
	{
		if(str[i]=='\0')
		break;
		else
		l++;	
	}
	/*alternative:
	while(str[i]1='\0')
	{
	i++;
	}
	printf("%d",i);*/
	printf("length = %d",l);
}
