#include<stdio.h>
main()
{
	printf("today is tuesday");
	
}
