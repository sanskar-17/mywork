//arithmatic operations on characters
#include<stdio.h>
main()
{
	char a='a',b='b';
	long int addn,subtn,multn,divdn,modulus;
	addn=a+2;
//	subtn=a-b;
//	multn=a*b;
//	divdn=a/b;
//	modulus=a%b;
	printf(" sum= %d",addn);
//	printf("\n subtraction= %c",subtn);
//	printf("\n product= %c",multn);
//	printf("\n quotient= %c",divdn);
//	printf("\n remainder= %c",modulus);
	
}
