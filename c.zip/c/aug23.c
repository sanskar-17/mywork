#include<stdio.h>
main()
{
	int a=2,b=4;//a=00000010 b=00000100
	printf("%d",(a&b));
	printf("\n%d",(a|b));	
	printf("\n%d",(a^b));	
	printf("\n%d",(~b));   //output = -(b+1)
	printf("\n%d",(a<<2));	
	printf("\n%d",(a>>2));	
	
}
