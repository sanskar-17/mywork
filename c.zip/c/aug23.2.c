#include<stdio.h>
main()
{
	float f;
	char ch='w';
	double d;
	int a=5,b=2,c;
	c=a+ch;	
	printf("value of c is %d ",c);
	printf("\ndivision is %d ",5/2);
	printf("\ndivision is %f ",5.0/2.0);
	printf("\ndivision is %f ",(float)5/2);
	
}
