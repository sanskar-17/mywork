#include<stdio.h>
main()
{
	int i,n,fact;
	int *pn;
	int *pfact;
	pn=&n;
	pfact=&fact;
	printf("enter the no. whose factorial u want to find\n");
	// instead of the following statement *pn=5 cam also be used
	scanf("%d",pn);
	for(i=1;i<=*pn;i++)
	{
		*pfact*=i;
	}
	printf("the factorial value is %d",*pfact);
}
