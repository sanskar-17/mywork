#include<stdio.h>
main()
{
	int arr[10],i;
	for(i=0;i<10;i++)
	{
		printf("enter the element into array\n");
		scanf("%d",&arr[i]);
	}
		for(i=0;i<10;i++)
		printf("%d\n",arr[i]);	
		for(i=0;i<10;i++)
		printf("%d",arr[i]);
}
