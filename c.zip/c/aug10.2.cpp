#include<stdio.h>
main()
{
	signed char c;
	c=127;
	printf("%c",c);
}
