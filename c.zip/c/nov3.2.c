#include<stdio.h>
#include<string.h>
#include<stdlib.h>
main()
{
	char str[200];
	printf("enter the string\n");
	gets(str);
	printf("original string is %s\n",str);
	int i=0;
	while (str[i]!='\0')
	{
		if(str[i]==' ')
		str[i]='&';
		i++;
	}
	printf("new string is %s\n",str);
}
