//no parameter and no return
#include<stdio.h>
void print1();
main()
{
	print1();//function calling
	print1();
}
void print1()
{
	printf("hello\n");
}
