#include <stdio.h>

#define NUM_USERS 3
#define NUM_ITEMS 3

int user_item_matrix[NUM_USERS][NUM_ITEMS];
float item_item_similarity_matrix[NUM_ITEMS][NUM_ITEMS];

void create_user_item_matrix() {
    // Initialize the user-item matrix with user ratings
    user_item_matrix[0][0] = 5;
    user_item_matrix[0][1] = 4;
    user_item_matrix[0][2] = 3;
    user_item_matrix[1][0] = 4;
    user_item_matrix[1][1] = 5;
    user_item_matrix[1][2] = 2;
    user_item_matrix[2][0] = 3;
    user_item_matrix[2][1] = 2;
    user_item_matrix[2][2] = 5;
}

void create_item_item_similarity_matrix() {
    // Calculate item-item similarity based on cosine similarity
    for (int i = 0; i < NUM_ITEMS; i++) {
        for (int j = 0; j < NUM_ITEMS; j++) {
            if (i == j) {
                item_item_similarity_matrix[i][j] = 1.0; // Items are identical
            } else {
                // Calculate the cosine similarity (simplified for demonstration)
                int dot_product = 0;
                int norm_i = 0;
                int norm_j = 0;
                for (int user = 0; user < NUM_USERS; user++) {
                    dot_product += user_item_matrix[user][i] * user_item_matrix[user][j];
                    norm_i += user_item_matrix[user][i] * user_item_matrix[user][i];
                    norm_j += user_item_matrix[user][j] * user_item_matrix[user][j];
                }
                item_item_similarity_matrix[i][j] = dot_product / (sqrt(norm_i) * sqrt(norm_j));
            }
        }
    }
}

int main() {
    create_user_item_matrix();
    create_item_item_similarity_matrix();

    // Example: Recommend items for user 1
    int user_id = 0;
    int top_n = 3;

    int user_ratings[NUM_ITEMS];
    for (int i = 0; i < NUM_ITEMS; i++) {
        user_ratings[i] = user_item_matrix[user_id][i];
    }

    int recommendations[NUM_ITEMS];
    int num_recommendations = 0;

    for (int i = 0; i < NUM_ITEMS; i++) {
        if (user_ratings[i] == 0) {
            recommendations[num_recommendations] = i;
            num_recommendations++;
        }
    }

    printf("Recommended items for user %d: ", user_id);
    for (int i = 0; i < num_recommendations && i < top_n; i++) {
        printf("%d ", recommendations[i]);
    }
    printf("\n");

    return 0;
}

