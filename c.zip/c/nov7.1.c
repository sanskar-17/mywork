#include<stdio.h>
#include<string.h>
struct student
{
	char name[20];
	int rollno;
	float cgpa;
}s2,s3;
main()
{
/*	struct student s1;
	strcpy(s1.name,"rohit");
	s1.rollno=45;
	s1.cgpa=9.4;*/ //this is one way to declare
//	struct student s1={"asdf",45,8.7	}; this is another way
	struct student s1,s4;
	gets(s1.name);
	scanf("%d",&s1.rollno);
	scanf("%f",&s1.cgpa);
	puts(s1.name);
	s4=s1;
//	printf("name is %s,roll no. is %d,cgpa is %.2f\n",s1.name,s1.rollno,s1.cgpa);
	printf("roll no. is %d,cgpa is %.2f\n",s4.rollno,s4.cgpa);
	
}
