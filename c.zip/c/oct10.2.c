#include<stdio.h>
main()
{
	int i;
	int a[7]={3,4,10,1,7,8,9};
	for(i=0;i<7;i++)
	printf("%d\n",a[i]);
	//deletion
	for(i=2;i<6;i++)
	a[i]=a[i+1];
	printf("The new array is\n");
	for(i=0;i<6;i++)
	printf("%d\n",a[i]);
}
