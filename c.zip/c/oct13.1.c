#include<stdio.h>
main()
{
	int a=9;
	int *aptr;
	aptr=&a;
	printf("value of a is %d\n",a);
	printf("address of a is %d\n",&a);
	printf("address of aptr pointer is %u\n",&aptr);
	printf("address of a using aptr is %u\n",aptr);
	printf("value held at pointer aptr is %d\n",*aptr);
}
